/* Smart QR SaaS – Admin JavaScript */
(function ($) {
    'use strict';

    $(function () {

        /* ── QR kép lazy load hibakezelés ── */
        $('img[src*="smart_qr_saas_image"]').on('error', function () {
            $(this).attr('src', '').closest('td').html('<span style="color:#aaa;font-size:11px;">–</span>');
        });

        /* ── Copy rövid link vágólapra ── */
        $(document).on('click', '.sqr-copy-btn', function (e) {
            e.preventDefault();
            var url = $(this).data('url');
            if (navigator.clipboard && url) {
                navigator.clipboard.writeText(url).then(function () {
                    var btn = this;
                    $(btn).text('✅').delay(1500).queue(function () {
                        $(btn).text('📋').dequeue();
                    });
                }.bind(this));
            }
        });

        /* ── Link form: jelszó mező toggle ── */
        var pwCheck = document.getElementById('sqr_pw_check');
        var pwRow   = document.getElementById('sqr_pw_row');
        if (pwCheck && pwRow) {
            pwCheck.addEventListener('change', function () {
                pwRow.style.display = this.checked ? '' : 'none';
            });
        }

        /* ── Dismiss notice ── */
        $(document).on('click', '.notice .notice-dismiss', function () {
            $(this).closest('.notice').fadeOut(200);
        });

    });

})(jQuery);
