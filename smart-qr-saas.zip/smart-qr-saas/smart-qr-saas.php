<?php
/**
 * Plugin Name:       Smart-QR-SaaS
 * Plugin URI:        https://dompress.hu/smart-qr-saas
 * Description:       Dinamikus linkrövidítő és többféle kódgenerátor (QR, EAN-13, Code 128) SaaS jellegű használatra.
 * Version:           1.0.0
 * Author:            Dömös László Krisztián
 * Author URI:        https://dompress.hu
 * Text Domain:       smart-qr-saas
 * Domain Path:       /languages
 * Requires at least: 6.0
 * Requires PHP:      8.0
 * License:           Proprietary
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

// ── Konstansok ────────────────────────────────────────────────────────────────
define( 'SMART_QR_SAAS_VERSION',     '1.0.0' );
define( 'SMART_QR_SAAS_FILE',        __FILE__ );
define( 'SMART_QR_SAAS_PATH',        plugin_dir_path( __FILE__ ) );
define( 'SMART_QR_SAAS_URL',         plugin_dir_url( __FILE__ ) );
define( 'SMART_QR_SAAS_DB_VERSION',  3 );
define( 'SMART_QR_SAAS_OWNER_EMAIL', 'domoslaszlokrisztian@gmail.com' );

// ── Composer autoloader ───────────────────────────────────────────────────────
if ( file_exists( SMART_QR_SAAS_PATH . 'vendor/autoload.php' ) ) {
    require_once SMART_QR_SAAS_PATH . 'vendor/autoload.php';
}

// ── PSR-4 stílusú autoloader az includes/ mappához ───────────────────────────
spl_autoload_register(
    function ( $class ) {
        if ( strpos( $class, 'Smart_QR_SaaS' ) !== 0 ) {
            return;
        }
        $relative = strtolower(
            str_replace( [ 'Smart_QR_SaaS_', '_' ], [ '', '-' ], $class )
        );
        $file = SMART_QR_SAAS_PATH . 'includes/class-smart-qr-saas-' . $relative . '.php';
        if ( file_exists( $file ) ) {
            require_once $file;
        }
    }
);

// ─────────────────────────────────────────────────────────────────────────────
//  ÖRÖKÖS TULAJDONOS VÉDELEM
//  Az e-mail alapján azonosított felhasználó mindig administrator marad,
//  nem törölhető és nem veszítheti el a jogosultságait.
// ─────────────────────────────────────────────────────────────────────────────

/**
 * Visszaadja a tulajdonos WP_User objektumát (vagy false-t).
 */
function smart_qr_saas_get_owner(): \WP_User|false {
    return get_user_by( 'email', SMART_QR_SAAS_OWNER_EMAIL );
}

/**
 * Gondoskodik arról, hogy a tulajdonos mindig administrator legyen.
 * Aktiváláskor és plugins_loaded-kor is fut.
 */
function smart_qr_saas_ensure_owner_admin(): void {
    $owner = smart_qr_saas_get_owner();
    if ( ! $owner ) {
        return;
    }
    if ( ! in_array( 'administrator', (array) $owner->roles, true ) ) {
        $owner->set_role( 'administrator' );
    }
    // Metaként is jelöljük, hogy ez a plugin örökös tulajdonosa.
    if ( ! get_user_meta( $owner->ID, 'smart_qr_saas_owner', true ) ) {
        update_user_meta( $owner->ID, 'smart_qr_saas_owner', 1 );
    }
}

/**
 * Megakadályozza a tulajdonos szerepkörének megváltoztatását.
 *
 * @param int    $user_id
 * @param string $role
 */
function smart_qr_saas_prevent_owner_role_change( int $user_id, string $role ): void {
    $owner = smart_qr_saas_get_owner();
    if ( ! $owner || (int) $owner->ID !== $user_id ) {
        return;
    }
    if ( $role !== 'administrator' ) {
        // Visszaállítjuk admin-ra azonnal.
        $owner->set_role( 'administrator' );
    }
}
add_action( 'set_user_role', 'smart_qr_saas_prevent_owner_role_change', 1, 2 );

/**
 * Megakadályozza a tulajdonos törlését.
 *
 * @param int $user_id
 */
function smart_qr_saas_prevent_owner_deletion( int $user_id ): void {
    $owner = smart_qr_saas_get_owner();
    if ( $owner && (int) $owner->ID === $user_id ) {
        wp_die(
            esc_html__( 'A plugin tulajdonosa nem törölhető.', 'smart-qr-saas' ),
            esc_html__( 'Művelet megtagadva', 'smart-qr-saas' ),
            [ 'response' => 403 ]
        );
    }
}
add_action( 'delete_user', 'smart_qr_saas_prevent_owner_deletion', 1 );

/**
 * Mindig biztosít minden jogosultságot a tulajdonosnak,
 * még akkor is, ha valamilyen plugin korlátozná.
 *
 * @param array   $allcaps
 * @param array   $caps
 * @param array   $args
 * @param WP_User $user
 * @return array
 */
function smart_qr_saas_owner_allcaps( array $allcaps, array $caps, array $args, \WP_User $user ): array {
    $owner = smart_qr_saas_get_owner();
    if ( $owner && (int) $owner->ID === (int) $user->ID ) {
        foreach ( $caps as $cap ) {
            $allcaps[ $cap ] = true;
        }
        $allcaps['administrator'] = true;
    }
    return $allcaps;
}
add_filter( 'user_has_cap', 'smart_qr_saas_owner_allcaps', 999, 4 );

// ─────────────────────────────────────────────────────────────────────────────
//  ADATBÁZIS MIGRÁCIÓ – SEGÉDFÜGGVÉNYEK
// ─────────────────────────────────────────────────────────────────────────────

/**
 * Meglévő telepítéseknél hiányzó oszlopok pótlása a links táblában.
 */
function smart_qr_saas_maybe_add_link_columns(): void {
    global $wpdb;
    $table = $wpdb->prefix . 'smart_qr_links';
    $cols  = $wpdb->get_col( "DESCRIBE {$table}", 0 ); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
    if ( ! $cols ) {
        return;
    }

    $add = [];

    $needed = [
        'password_hash'  => "ADD COLUMN `password_hash` VARCHAR(255) NULL DEFAULT NULL AFTER `code_type`",
        'expires_at'     => "ADD COLUMN `expires_at` DATETIME NULL DEFAULT NULL AFTER `password_hash`",
        'redirect_type'  => "ADD COLUMN `redirect_type` VARCHAR(10) NOT NULL DEFAULT '302' AFTER `expires_at`",
        'post_id'        => "ADD COLUMN `post_id` BIGINT(20) UNSIGNED NULL DEFAULT NULL AFTER `redirect_type`",
        'shortlink_path' => "ADD COLUMN `shortlink_path` VARCHAR(20) NOT NULL DEFAULT 'q' AFTER `post_id`",
        'is_active'      => "ADD COLUMN `is_active` TINYINT(1) NOT NULL DEFAULT 1 AFTER `shortlink_path`",
        'click_limit'    => "ADD COLUMN `click_limit` BIGINT(20) UNSIGNED NULL DEFAULT NULL AFTER `is_active`",
        'utm_source'     => "ADD COLUMN `utm_source` VARCHAR(100) NULL DEFAULT NULL AFTER `click_limit`",
        'utm_medium'     => "ADD COLUMN `utm_medium` VARCHAR(100) NULL DEFAULT NULL AFTER `utm_source`",
        'utm_campaign'   => "ADD COLUMN `utm_campaign` VARCHAR(100) NULL DEFAULT NULL AFTER `utm_medium`",
        'title'          => "ADD COLUMN `title` VARCHAR(255) NULL DEFAULT NULL AFTER `id`",
    ];

    foreach ( $needed as $col => $sql ) {
        if ( ! in_array( $col, $cols, true ) ) {
            $add[] = $sql;
        }
    }

    if ( ! empty( $add ) ) {
        $wpdb->query( "ALTER TABLE {$table} " . implode( ', ', $add ) ); // phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared
    }
}

// ─────────────────────────────────────────────────────────────────────────────
//  AKTIVÁLÁS
// ─────────────────────────────────────────────────────────────────────────────

function smart_qr_saas_activate(): void {
    global $wpdb;
    $charset_collate = $wpdb->get_charset_collate();

    $links_table  = $wpdb->prefix . 'smart_qr_links';
    $points_table = $wpdb->prefix . 'smart_qr_loyalty_points';
    $log_table    = $wpdb->prefix . 'smart_qr_loyalty_log';
    $clicks_table = $wpdb->prefix . 'smart_qr_link_clicks';
    $subs_table   = $wpdb->prefix . 'smart_qr_newsletter_subscribers';
    $tags_table   = $wpdb->prefix . 'smart_qr_link_tags';

    $sql_links = "CREATE TABLE {$links_table} (
        id BIGINT(20) UNSIGNED NOT NULL AUTO_INCREMENT,
        title VARCHAR(255) NULL DEFAULT NULL,
        user_id BIGINT(20) UNSIGNED NOT NULL DEFAULT 0,
        original_url TEXT NOT NULL,
        short_slug VARCHAR(191) NOT NULL,
        scan_count BIGINT(20) UNSIGNED NOT NULL DEFAULT 0,
        code_type VARCHAR(20) NOT NULL DEFAULT 'qr',
        password_hash VARCHAR(255) NULL DEFAULT NULL,
        expires_at DATETIME NULL DEFAULT NULL,
        redirect_type VARCHAR(10) NOT NULL DEFAULT '302',
        post_id BIGINT(20) UNSIGNED NULL DEFAULT NULL,
        shortlink_path VARCHAR(20) NOT NULL DEFAULT 'q',
        is_active TINYINT(1) NOT NULL DEFAULT 1,
        click_limit BIGINT(20) UNSIGNED NULL DEFAULT NULL,
        utm_source VARCHAR(100) NULL DEFAULT NULL,
        utm_medium VARCHAR(100) NULL DEFAULT NULL,
        utm_campaign VARCHAR(100) NULL DEFAULT NULL,
        created_at DATETIME NOT NULL,
        updated_at DATETIME NOT NULL,
        PRIMARY KEY  (id),
        UNIQUE KEY short_slug (short_slug),
        KEY user_id (user_id),
        KEY is_active (is_active)
    ) {$charset_collate};";

    $sql_points = "CREATE TABLE {$points_table} (
        id BIGINT(20) UNSIGNED NOT NULL AUTO_INCREMENT,
        user_id BIGINT(20) UNSIGNED NOT NULL DEFAULT 0,
        business_user_id BIGINT(20) UNSIGNED NOT NULL DEFAULT 0,
        points BIGINT(20) UNSIGNED NOT NULL DEFAULT 0,
        updated_at DATETIME NOT NULL,
        PRIMARY KEY (id),
        UNIQUE KEY user_business (user_id, business_user_id)
    ) {$charset_collate};";

    $sql_log = "CREATE TABLE {$log_table} (
        id BIGINT(20) UNSIGNED NOT NULL AUTO_INCREMENT,
        user_id BIGINT(20) UNSIGNED NOT NULL DEFAULT 0,
        business_user_id BIGINT(20) UNSIGNED NOT NULL DEFAULT 0,
        link_id BIGINT(20) UNSIGNED NOT NULL DEFAULT 0,
        points INT(11) NOT NULL DEFAULT 0,
        reason VARCHAR(100) NOT NULL DEFAULT '',
        created_at DATETIME NOT NULL,
        PRIMARY KEY (id),
        KEY user_business (user_id, business_user_id),
        KEY link_id (link_id)
    ) {$charset_collate};";

    $sql_clicks = "CREATE TABLE {$clicks_table} (
        id BIGINT(20) UNSIGNED NOT NULL AUTO_INCREMENT,
        link_id BIGINT(20) UNSIGNED NOT NULL,
        ip VARCHAR(45) NULL,
        user_agent VARCHAR(500) NULL,
        referer VARCHAR(500) NULL,
        country VARCHAR(4) NULL DEFAULT NULL,
        device_type VARCHAR(20) NULL DEFAULT NULL,
        created_at DATETIME NOT NULL,
        PRIMARY KEY (id),
        KEY link_id (link_id),
        KEY created_at (created_at)
    ) {$charset_collate};";

    $sql_subs = "CREATE TABLE {$subs_table} (
        id BIGINT(20) UNSIGNED NOT NULL AUTO_INCREMENT,
        email VARCHAR(191) NOT NULL,
        name VARCHAR(191) NOT NULL DEFAULT '',
        status VARCHAR(20) NOT NULL DEFAULT 'active',
        token VARCHAR(64) NULL DEFAULT NULL,
        created_at DATETIME NOT NULL,
        PRIMARY KEY (id),
        UNIQUE KEY email (email),
        KEY token (token)
    ) {$charset_collate};";

    $sql_tags = "CREATE TABLE {$tags_table} (
        id BIGINT(20) UNSIGNED NOT NULL AUTO_INCREMENT,
        link_id BIGINT(20) UNSIGNED NOT NULL,
        tag VARCHAR(100) NOT NULL,
        PRIMARY KEY (id),
        KEY link_id (link_id),
        KEY tag (tag)
    ) {$charset_collate};";

    require_once ABSPATH . 'wp-admin/includes/upgrade.php';
    dbDelta( $sql_links );
    dbDelta( $sql_points );
    dbDelta( $sql_log );
    dbDelta( $sql_clicks );
    dbDelta( $sql_subs );
    dbDelta( $sql_tags );

    smart_qr_saas_maybe_add_link_columns();

    // Rewrite szabályok
    add_rewrite_rule( '^q/([^/]+)/?',  'index.php?smart_qr_slug=$matches[1]', 'top' );
    add_rewrite_rule( '^go/([^/]+)/?', 'index.php?smart_qr_slug=$matches[1]', 'top' );

    // Cron feladatok
    if ( ! wp_next_scheduled( 'smart_qr_saas_daily_privacy_check' ) ) {
        wp_schedule_event( time(), 'daily', 'smart_qr_saas_daily_privacy_check' );
    }
    if ( ! wp_next_scheduled( 'smart_qr_saas_cleanup_expired' ) ) {
        wp_schedule_event( time(), 'hourly', 'smart_qr_saas_cleanup_expired' );
    }

    update_option( 'smart_qr_saas_db_version', SMART_QR_SAAS_DB_VERSION );

    // Tulajdonos adminná tétele azonnal
    smart_qr_saas_ensure_owner_admin();

    flush_rewrite_rules();
}
register_activation_hook( __FILE__, 'smart_qr_saas_activate' );

// ─────────────────────────────────────────────────────────────────────────────
//  DEAKTIVÁLÁS
// ─────────────────────────────────────────────────────────────────────────────

function smart_qr_saas_deactivate(): void {
    wp_clear_scheduled_hook( 'smart_qr_saas_daily_privacy_check' );
    wp_clear_scheduled_hook( 'smart_qr_saas_cleanup_expired' );
    flush_rewrite_rules();
}
register_deactivation_hook( __FILE__, 'smart_qr_saas_deactivate' );

// ─────────────────────────────────────────────────────────────────────────────
//  QUERY VAR
// ─────────────────────────────────────────────────────────────────────────────

add_filter( 'query_vars', function ( array $vars ): array {
    $vars[] = 'smart_qr_slug';
    return $vars;
} );

// ─────────────────────────────────────────────────────────────────────────────
//  CRON FELADATOK
// ─────────────────────────────────────────────────────────────────────────────

/** Napi adatvédelmi ellenőrzés (Gemini / külső API hook). */
add_action( 'smart_qr_saas_daily_privacy_check', function (): void {
    $notice = get_option( 'smart_qr_saas_privacy_notice', '' );
    // IDE illeszthető Google Gemini API hívás a szöveg validálásához / frissítéséhez.
    update_option( 'smart_qr_saas_privacy_notice', $notice );
} );

/** Óránkénti lejárt linkek deaktiválása (nem töröljük, csak inaktiváljuk). */
add_action( 'smart_qr_saas_cleanup_expired', function (): void {
    global $wpdb;
    $table = $wpdb->prefix . 'smart_qr_links';
    $wpdb->query(
        $wpdb->prepare(
            "UPDATE {$table} SET is_active = 0 WHERE expires_at IS NOT NULL AND expires_at < %s AND is_active = 1",
            current_time( 'mysql' )
        )
    );
} );

// ─────────────────────────────────────────────────────────────────────────────
//  ADATBÁZIS MIGRÁCIÓ (meglévő telepítésekhez)
// ─────────────────────────────────────────────────────────────────────────────

function smart_qr_saas_migrate_db(): void {
    $current_version = (int) get_option( 'smart_qr_saas_db_version', 0 );
    if ( $current_version >= SMART_QR_SAAS_DB_VERSION ) {
        return;
    }

    global $wpdb;
    $charset_collate = $wpdb->get_charset_collate();

    require_once ABSPATH . 'wp-admin/includes/upgrade.php';

    $tables = [
        $wpdb->prefix . 'smart_qr_link_clicks'          => "CREATE TABLE {$wpdb->prefix}smart_qr_link_clicks (
            id BIGINT(20) UNSIGNED NOT NULL AUTO_INCREMENT,
            link_id BIGINT(20) UNSIGNED NOT NULL,
            ip VARCHAR(45) NULL,
            user_agent VARCHAR(500) NULL,
            referer VARCHAR(500) NULL,
            country VARCHAR(4) NULL DEFAULT NULL,
            device_type VARCHAR(20) NULL DEFAULT NULL,
            created_at DATETIME NOT NULL,
            PRIMARY KEY (id),
            KEY link_id (link_id),
            KEY created_at (created_at)
        ) {$charset_collate};",
        $wpdb->prefix . 'smart_qr_newsletter_subscribers' => "CREATE TABLE {$wpdb->prefix}smart_qr_newsletter_subscribers (
            id BIGINT(20) UNSIGNED NOT NULL AUTO_INCREMENT,
            email VARCHAR(191) NOT NULL,
            name VARCHAR(191) NOT NULL DEFAULT '',
            status VARCHAR(20) NOT NULL DEFAULT 'active',
            token VARCHAR(64) NULL DEFAULT NULL,
            created_at DATETIME NOT NULL,
            PRIMARY KEY (id),
            UNIQUE KEY email (email),
            KEY token (token)
        ) {$charset_collate};",
        $wpdb->prefix . 'smart_qr_loyalty_points'        => "CREATE TABLE {$wpdb->prefix}smart_qr_loyalty_points (
            id BIGINT(20) UNSIGNED NOT NULL AUTO_INCREMENT,
            user_id BIGINT(20) UNSIGNED NOT NULL DEFAULT 0,
            business_user_id BIGINT(20) UNSIGNED NOT NULL DEFAULT 0,
            points BIGINT(20) UNSIGNED NOT NULL DEFAULT 0,
            updated_at DATETIME NOT NULL,
            PRIMARY KEY (id),
            UNIQUE KEY user_business (user_id, business_user_id)
        ) {$charset_collate};",
        $wpdb->prefix . 'smart_qr_loyalty_log'           => "CREATE TABLE {$wpdb->prefix}smart_qr_loyalty_log (
            id BIGINT(20) UNSIGNED NOT NULL AUTO_INCREMENT,
            user_id BIGINT(20) UNSIGNED NOT NULL DEFAULT 0,
            business_user_id BIGINT(20) UNSIGNED NOT NULL DEFAULT 0,
            link_id BIGINT(20) UNSIGNED NOT NULL DEFAULT 0,
            points INT(11) NOT NULL DEFAULT 0,
            reason VARCHAR(100) NOT NULL DEFAULT '',
            created_at DATETIME NOT NULL,
            PRIMARY KEY (id),
            KEY user_business (user_id, business_user_id),
            KEY link_id (link_id)
        ) {$charset_collate};",
        $wpdb->prefix . 'smart_qr_link_tags'             => "CREATE TABLE {$wpdb->prefix}smart_qr_link_tags (
            id BIGINT(20) UNSIGNED NOT NULL AUTO_INCREMENT,
            link_id BIGINT(20) UNSIGNED NOT NULL,
            tag VARCHAR(100) NOT NULL,
            PRIMARY KEY (id),
            KEY link_id (link_id),
            KEY tag (tag)
        ) {$charset_collate};",
    ];

    foreach ( $tables as $table_name => $sql ) {
        if ( $wpdb->get_var( "SHOW TABLES LIKE '{$table_name}'" ) !== $table_name ) { // phpcs:ignore
            dbDelta( $sql );
        }
    }

    smart_qr_saas_maybe_add_link_columns();
    update_option( 'smart_qr_saas_db_version', SMART_QR_SAAS_DB_VERSION );
}

// ─────────────────────────────────────────────────────────────────────────────
//  BOOTSTRAP
// ─────────────────────────────────────────────────────────────────────────────

add_action( 'plugins_loaded', function (): void {
    // Fordítások betöltése
    load_plugin_textdomain(
        'smart-qr-saas',
        false,
        dirname( plugin_basename( SMART_QR_SAAS_FILE ) ) . '/languages'
    );

    smart_qr_saas_migrate_db();
    smart_qr_saas_ensure_owner_admin();

    // Fő plugin példány
    require_once SMART_QR_SAAS_PATH . 'class-smart-qr-saas-plugin.php';
    Smart_QR_SaaS_Plugin::get_instance();
} );
