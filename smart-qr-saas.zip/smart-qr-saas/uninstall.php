<?php
/**
 * Smart-QR-SaaS – Eltávolítás
 *
 * Fut, amikor az adminisztrátor törli a plugint a WP adminból.
 * Eltávolítja az összes adatbázis táblát, opciót és cron feladatot.
 */

if ( ! defined( 'WP_UNINSTALL_PLUGIN' ) ) {
    exit;
}

global $wpdb;

// ── Táblák törlése ─────────────────────────────────────────────────────────
$tables = [
    $wpdb->prefix . 'smart_qr_links',
    $wpdb->prefix . 'smart_qr_link_clicks',
    $wpdb->prefix . 'smart_qr_link_tags',
    $wpdb->prefix . 'smart_qr_loyalty_points',
    $wpdb->prefix . 'smart_qr_loyalty_log',
    $wpdb->prefix . 'smart_qr_newsletter_subscribers',
];

foreach ( $tables as $table ) {
    $wpdb->query( "DROP TABLE IF EXISTS `{$table}`" ); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
}

// ── Plugin opciók törlése ──────────────────────────────────────────────────
$options = [
    'smart_qr_saas_db_version',
    'smart_qr_saas_privacy_notice',
    'smart_qr_saas_ai_api_key',
    'smart_qr_saas_shortlink_path',
    'smart_qr_saas_allow_editor_newsletter',
    'smart_qr_saas_wc_required',
];

foreach ( $options as $option ) {
    delete_option( $option );
}

// ── Felhasználói meta törlése ──────────────────────────────────────────────
$wpdb->delete( $wpdb->usermeta, [ 'meta_key' => 'smart_qr_ai_history' ],  [ '%s' ] );
$wpdb->delete( $wpdb->usermeta, [ 'meta_key' => 'smart_qr_saas_owner' ],  [ '%s' ] );

// ── Cron feladatok törlése ─────────────────────────────────────────────────
wp_clear_scheduled_hook( 'smart_qr_saas_daily_privacy_check' );
wp_clear_scheduled_hook( 'smart_qr_saas_cleanup_expired' );

// ── Rewrite szabályok frissítése ───────────────────────────────────────────
flush_rewrite_rules();
